package com.synex.injector

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.TextFieldValue
import androidx.activity.compose.BackHandler
import java.io.BufferedReader
import java.io.InputStreamReader

private val Bg = Color(0xFF070A12)
private val Surface = Color(0xFF101624)
private val Surface2 = Color(0xFF151F31)
private val Cyan = Color(0xFF00F0FF)
private val Violet = Color(0xFF9D5CFF)
private val TextMain = Color(0xFFEAF7FF)
private val Muted = Color(0xFF8497B2)
private val Border = Color(0xFF26364E)
private val Green = Color(0xFF6BFFC4)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(7, 10, 18)
        window.navigationBarColor = android.graphics.Color.rgb(7, 10, 18)
        window.decorView.systemUiVisibility = 0
        setContent { SynexApp() }
    }
}

@Composable
private fun SynexApp() {
    val context = LocalContext.current
    var script by remember { mutableStateOf("-- Welcome to Synex\\n-- Paste or write your Lua text here.\\n\\nprint(\\"Hello, Synex!\\")") }
    var status by remember { mutableStateOf("SYSTEM READY  •  UI DEMO") }
    var fileName by remember { mutableStateOf("untitled.lua") }

    val openFile = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.openInputStream(uri)?.use { stream ->
                    BufferedReader(InputStreamReader(stream)).readText()
                } ?: ""
            }.onSuccess {
                script = it
                fileName = uri.lastPathSegment?.substringAfterLast('/') ?: "opened.lua"
                status = "FILE LOADED  •  ${fileName.uppercase()}"
            }.onFailure {
                status = "COULD NOT OPEN FILE"
            }
        }
    }

    val saveFile = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("text/plain")
    ) { uri ->
        if (uri != null) {
            runCatching {
                context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(script) }
            }.onSuccess {
                status = "FILE SAVED  •  SUCCESS"
            }.onFailure {
                status = "SAVE FAILED"
            }
        }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Cyan,
            secondary = Violet,
            background = Bg,
            surface = Surface,
            onPrimary = Bg,
            onBackground = TextMain,
            onSurface = TextMain
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(listOf(Color(0xFF10152A), Bg, Color(0xFF070A12)))
                )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Header()
                StatusCard(status)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    SmallStat("MODE", "LOCAL UI", Icons.Default.Terminal, Modifier.weight(1f))
                    SmallStat("ENGINE", "DEMO ONLY", Icons.Default.Shield, Modifier.weight(1f))
                }
                EditorCard(
                    fileName = fileName,
                    script = script,
                    onScriptChange = { script = it },
                    onOpen = { openFile.launch(arrayOf("text/*", "application/octet-stream")) },
                    onSave = { saveFile.launch(fileName.ifBlank { "untitled.lua" }) },
                    onClear = {
                        script = ""
                        status = "EDITOR CLEARED"
                    }
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    NeonButton(
                        label = "ATTACH",
                        icon = Icons.Default.Link,
                        modifier = Modifier.weight(1f),
                        outlined = true
                    ) { status = "DEMO MODE  •  NO APP ATTACHED" }
                    NeonButton(
                        label = "EXECUTE",
                        icon = Icons.Default.PlayArrow,
                        modifier = Modifier.weight(1f),
                        outlined = false
                    ) { status = "UI DEMO ONLY  •  NO CODE EXECUTED" }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    NeonButton(
                        label = "OPEN FILE",
                        icon = Icons.Default.FolderOpen,
                        modifier = Modifier.weight(1f),
                        outlined = true
                    ) { openFile.launch(arrayOf("text/*", "application/octet-stream")) }
                    NeonButton(
                        label = "SAVE FILE",
                        icon = Icons.Default.Save,
                        modifier = Modifier.weight(1f),
                        outlined = true
                    ) { saveFile.launch(fileName.ifBlank { "untitled.lua" }) }
                }
                Footer()
                Spacer(Modifier.height(8.dp))
            }
        }
    }
}

@Composable
private fun Header() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(16.dp, RoundedCornerShape(22.dp))
            .background(Surface.copy(alpha = 0.96f), RoundedCornerShape(22.dp))
            .border(1.dp, Brush.horizontalGradient(listOf(Cyan.copy(alpha = 0.8f), Violet.copy(alpha = 0.5f), Border)), RoundedCornerShape(22.dp))
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(48.dp)
                .background(Brush.linearGradient(listOf(Cyan, Violet)), RoundedCornerShape(15.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.Bolt, contentDescription = null, tint = Bg, modifier = Modifier.size(30.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text("SYNEX", fontSize = 23.sp, fontWeight = FontWeight.Black, color = TextMain, letterSpacing = 2.sp)
            Text("INJECTOR  /  NEON INTERFACE", fontSize = 9.sp, color = Cyan, fontWeight = FontWeight.Bold, letterSpacing = 1.3.sp)
        }
        Column(horizontalAlignment = Alignment.End) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(7.dp).background(Green, RoundedCornerShape(50)))
                Spacer(Modifier.width(5.dp))
                Text("ONLINE", color = Green, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            }
            Text("v1.0.0", color = Muted, fontSize = 10.sp)
        }
    }
}

@Composable
private fun StatusCard(status: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF0C1B25), RoundedCornerShape(14.dp))
            .border(1.dp, Cyan.copy(alpha = 0.35f), RoundedCornerShape(14.dp))
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Default.Memory, contentDescription = null, tint = Cyan, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(10.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text("CONSOLE STATUS", color = Muted, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            Text(status, color = TextMain, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
        Icon(Icons.Default.GraphicEq, contentDescription = null, tint = Violet, modifier = Modifier.size(22.dp))
    }
}

@Composable
private fun SmallStat(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier) {
    Row(
        modifier = modifier
            .background(Surface, RoundedCornerShape(14.dp))
            .border(1.dp, Border, RoundedCornerShape(14.dp))
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = Cyan, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(9.dp))
        Column {
            Text(title, color = Muted, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            Text(value, color = TextMain, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun EditorCard(
    fileName: String,
    script: String,
    onScriptChange: (String) -> Unit,
    onOpen: () -> Unit,
    onSave: () -> Unit,
    onClear: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Surface, RoundedCornerShape(18.dp))
            .border(1.dp, Border, RoundedCornerShape(18.dp))
            .padding(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Code, contentDescription = null, tint = Cyan, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(8.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text("SCRIPT WORKSPACE", color = TextMain, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.7.sp)
                Text(fileName, color = Muted, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Box(
                modifier = Modifier
                    .background(Color(0xFF102E32), RoundedCornerShape(7.dp))
                    .padding(horizontal = 8.dp, vertical = 5.dp)
            ) {
                Text("LUA", color = Cyan, fontSize = 9.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
            }
        }
        Spacer(Modifier.height(12.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = 245.dp)
                .background(Color(0xFF080D16), RoundedCornerShape(12.dp))
                .border(1.dp, Color(0xFF1D2A3C), RoundedCornerShape(12.dp))
                .padding(10.dp)
        ) {
            Text("1\n2\n3\n4\n5\n6\n7\n8\n9\n10", color = Color(0xFF52637A), fontSize = 12.sp, lineHeight = 19.sp, fontFamily = FontFamily.Monospace)
            Spacer(Modifier.width(10.dp))
            BasicTextField(
                value = script,
                onValueChange = onScriptChange,
                modifier = Modifier
                    .weight(1f)
                    .heightIn(min = 225.dp),
                textStyle = TextStyle(
                    color = Color(0xFFB8F7FF),
                    fontSize = 12.sp,
                    lineHeight = 19.sp,
                    fontFamily = FontFamily.Monospace
                ),
                cursorBrush = Brush.verticalGradient(listOf(Cyan, Violet)),
                decorationBox = { inner ->
                    Box {
                        if (script.isEmpty()) {
                            Text("-- Type or paste your script text...", color = Muted, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                        }
                        inner()
                    }
                }
            )
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            MiniButton("OPEN", Icons.Default.FolderOpen, Modifier.weight(1f), onOpen)
            MiniButton("SAVE", Icons.Default.Save, Modifier.weight(1f), onSave)
            MiniButton("CLEAR", Icons.Default.DeleteOutline, Modifier.weight(1f), onClear)
        }
    }
}

@Composable
private fun MiniButton(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier, onClick: () -> Unit) {
    OutlinedButton(
        onClick = onClick,
        modifier = modifier.height(40.dp),
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, Border),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = Cyan),
        contentPadding = PaddingValues(horizontal = 7.dp, vertical = 0.dp)
    ) {
        Icon(icon, contentDescription = null, modifier = Modifier.size(15.dp))
        Spacer(Modifier.width(5.dp))
        Text(label, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.4.sp)
    }
}

@Composable
private fun NeonButton(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier,
    outlined: Boolean,
    onClick: () -> Unit
) {
    val shape = RoundedCornerShape(13.dp)
    val brush = Brush.horizontalGradient(listOf(Cyan, Violet))
    if (outlined) {
        OutlinedButton(
            onClick = onClick,
            modifier = modifier.height(48.dp),
            shape = shape,
            border = BorderStroke(1.dp, Cyan.copy(alpha = 0.65f)),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = Cyan),
            contentPadding = PaddingValues(horizontal = 8.dp)
        ) {
            Icon(icon, contentDescription = null, modifier = Modifier.size(17.dp))
            Spacer(Modifier.width(6.dp))
            Text(label, fontSize = 11.sp, fontWeight = FontWeight.Black, letterSpacing = 0.5.sp)
        }
    } else {
        Button(
            onClick = onClick,
            modifier = modifier
                .height(48.dp)
                .shadow(10.dp, shape),
            shape = shape,
            colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Bg),
            contentPadding = PaddingValues(horizontal = 8.dp)
        ) {
            Icon(icon, contentDescription = null, modifier = Modifier.size(17.dp))
            Spacer(Modifier.width(6.dp))
            Text(label, fontSize = 11.sp, fontWeight = FontWeight.Black, letterSpacing = 0.5.sp)
        }
    }
}

@Composable
private fun Footer() {
    Row(
        modifier = Modifier.fillMaxWidth().padding(top = 2.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Default.Shield, contentDescription = null, tint = Muted, modifier = Modifier.size(13.dp))
        Spacer(Modifier.width(6.dp))
        Text("STANDALONE INTERFACE  •  VISUAL DEMO ONLY", color = Muted, fontSize = 9.sp, letterSpacing = 0.6.sp)
    }
}
