# Synex Injector — Android UI Prototype

A standalone Android app UI built with Kotlin and Jetpack Compose. It is an interface demo only; Attach and Execute do not inject into other apps or execute code.

## Build on a computer
1. Install Android Studio (current stable) with Android SDK Platform 35.
2. Open this folder in Android Studio.
3. Allow Gradle sync to complete.
4. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Android Studio shows the APK location, usually `app/build/outputs/apk/debug/app-debug.apk`.

## Install on your Android phone
Transfer `app-debug.apk` to your phone and open it. If Android asks, allow installation from that file manager/browser for this install, then install.

## Features
- Neon black/cyan/violet standalone interface
- Editable monospace script text area
- Open file using Android document picker
- Save text to a selected destination
- Clear editor
- Attach / Execute buttons show demo status only

## Requirements
- Android Studio
- JDK 17 (Android Studio bundled JDK is fine)
- Android SDK Platform 35
